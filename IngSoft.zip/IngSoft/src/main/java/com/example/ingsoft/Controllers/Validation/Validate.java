package com.example.ingsoft.Controllers.Validation;


public interface Validate {
    final String cssRedBorder = "-fx-border-color: red ; -fx-border-width: 1px ;";
    public boolean validate();
}
