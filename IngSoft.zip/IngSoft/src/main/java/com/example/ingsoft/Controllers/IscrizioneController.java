package com.example.ingsoft.Controllers;


import com.example.ingsoft.Controllers.Validation.Validator;
import com.example.ingsoft.Model.ComuniProvider;
import com.example.ingsoft.Model.Lavoratore.Lavoratore;
import com.example.ingsoft.Model.Lavoratore.LavoratoreDaoImpl;
import com.example.ingsoft.Model.Persona.PersonaUrgente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class IscrizioneController {
    private final String cssRedBorder = "-fx-border-color: red ; -fx-border-width: 1px ;";
    private  Validator validator;
    private SortedSet<String> comuni;
    @FXML
    private TextField txtCognome, txtNome, txtLuogoNascita, txtNazionalita, txtRecTel, txtCitta, txtVia, txtCivico
            ,txtCap,txtEmail,txtLingua,txtPatente,txtNomeEmergenza, txtCognomeEmergenza, txtIndirizzoEmergenza, txtTelefonoEmergenza;
    private List<TextField> stringTextFields;
    @FXML
    private CheckBox checkAutomunito, checkBagnino, checkBarman, checkViticultore, checkFloricultore, checkIstruttoreNuoto;
    private List<CheckBox> specializzazioni;
    @FXML
    private DatePicker dPickerNascita,dPInizioLavoro,dPFineLavoro,dPInizioEsperienza,dPFineEsperienza;
    @FXML
    private ComboBox<String> comuneComboBox;
    private LavoratoreDaoImpl lavoratoreDaoImpl;
    @FXML
    private void handleIscrizione(ActionEvent event) {
        if(FormValid()){
            String nome, cognome,  telefonoPersonale,  email,  nazionalita,  patente, luogo;
            LocalDate dataDiNascita;
            PersonaUrgente personaUrgente;
            List<String> esperienzeEffettuate = new ArrayList<String>();
            List<String> lingueParlate;
            boolean automunito;
            nome = txtNome.getText();
            cognome = txtCognome.getText();
            telefonoPersonale = txtRecTel.getText();
            email = txtEmail.getText();
            luogo = txtLuogoNascita.getText();
            nazionalita = txtNazionalita.getText();
            patente = txtPatente.getText();
            dataDiNascita = dPickerNascita.getValue();
            for(CheckBox cb : specializzazioni){
                if(cb.isSelected()){
                    esperienzeEffettuate.add(cb.getText());
                }
            }
            personaUrgente = new PersonaUrgente(txtNomeEmergenza.getText(),txtCognomeEmergenza.getText(),txtTelefonoEmergenza.getText(),txtIndirizzoEmergenza.getText());
            esperienzeEffettuate = null;

            lingueParlate = Arrays.asList(txtLingua.getText().split(" "));
            automunito = checkAutomunito.isSelected();
            patente = txtPatente.getText();
            Lavoratore lavoratore = new Lavoratore(nome,cognome,telefonoPersonale, luogo, email, nazionalita, dataDiNascita, personaUrgente,
                    null, lingueParlate,automunito, patente, esperienzeEffettuate,comuni);
            lavoratoreDaoImpl.add(lavoratore);
            System.out.println(lavoratoreDaoImpl.getLavoratori());
            SalvasuFile();
            reset();
        }
    }
    private void reset(){
        for(TextField tf : stringTextFields )
            tf.setText("");
    }
    @FXML
    public void initialize() {
        stringTextFields = new ArrayList<TextField>();
        Collections.addAll(stringTextFields, txtCognome, txtNome, txtLuogoNascita, txtNazionalita, txtCitta, txtVia, txtCivico
                ,txtEmail,txtLingua,txtNomeEmergenza, txtCognomeEmergenza, txtIndirizzoEmergenza);
        for(TextField tf : stringTextFields){
                tf.setText("h");
        }
        txtTelefonoEmergenza.setText("3333333333");
        txtCap.setText("33333");
        dPickerNascita.setValue(LocalDate.of(1980,10,5));
        dPInizioLavoro.getEditor().setDisable(true);
        dPFineLavoro.getEditor().setDisable(true);
        dPickerNascita.getEditor().setDisable(true);
        dPInizioLavoro.setValue(LocalDate.of(2022,10,5));
        dPFineLavoro.setValue(LocalDate.of(2023,10,5));

        lavoratoreDaoImpl = new LavoratoreDaoImpl();
        comuni = new TreeSet<String>();
        validator = new Validator();
        specializzazioni = new ArrayList<CheckBox>();
        Collections.addAll(specializzazioni,checkBagnino,checkBarman,checkFloricultore,checkViticultore,checkIstruttoreNuoto);
        validator.add(stringTextFields);
        validator.add(txtCap,5);
        validator.add(txtTelefonoEmergenza,10);
        validator.add(txtRecTel,10,true);
        validator.add(dPickerNascita);
        validator.add(dPInizioLavoro,dPFineLavoro);
        fillComuniComboBox();
    }
    private void SalvasuFile(){
        try {
            FileOutputStream fileOutputStream
                    = new FileOutputStream("yourfile.txt");
            ObjectOutputStream objectOutputStream
                    = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(lavoratoreDaoImpl.getLavoratori());
        }catch(Exception e){
            System.out.println(e);
        }
    }
    private boolean FormValid() {
        return  validator.validate();
    }
    private void fillComuniComboBox(){
        ComuniProvider cp = ComuniProvider.getInstance();
        comuneComboBox.setItems(cp.getListaComuni());
    }
    @FXML
    private void ComboBoxClick(){
        String comuneScelto = comuneComboBox.getSelectionModel().getSelectedItem();
        comuni.add(comuneScelto);
    }
    public void backToPrincipalMenu(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("PrincipalMenu.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene  scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
