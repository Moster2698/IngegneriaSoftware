package com.example.ingsoft.Model.Lavoratore;

import com.example.ingsoft.Model.Lavoratore.Lavoratore;

import java.util.List;

public interface LavoratoreDao {
    public List<Lavoratore> getLavoratori();
    public void add(Lavoratore lavoratore);
}
